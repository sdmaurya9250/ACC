<?php

namespace App\Http\Controllers;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{
    public function loginForm(){

        return view('login');
    }

    public function showLoginForm()
    {
        return view('register');
    }

    public function loginUser(Request $request)
    {

        // Check if user exists
        $user = User::where('email', $request->input('email'))->first();
    
        if ($user && Hash::check($request->password, $user->password)) {
            // Use Laravel's built-in Auth::login to log in the user
          
            return redirect('user');
        } else {

            session()->flash('error', 'Invalid Datails');
            // Incorrect credentials, redirect back to the login page
            return redirect('login');
        }
    }

    public function submitForm(Request $request)
    {

        // return $request->post();
        // exit;
        $request->validate([
            'name' => 'required|string|max:255',
            'age' => 'required|integer',
            'education' => 'required|string|max:255',
        ]);

        $user = User::create($request->all());
        if ($user->age < 18) {
            return redirect('https://www.google.com');
        }
        return redirect('/login');
    }

   
    public function showUserData()
    {
        $user = User::all();
        return view('user', compact('user'));
    }

}
