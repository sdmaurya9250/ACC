<h1>User Data</h1>
 <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

<p>Name: <?php echo e($users->name); ?></p>
<p>Age: <?php echo e($users->age); ?></p>
<p>Education: <?php echo e($users->education); ?></p>
    
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
<style>
   #myChart{
     width: 500px!important;
     height: 500px!important;
   }

</style>

<!-- Include Chart.js library -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<!-- Add a canvas element for the chart -->
<canvas id="myChart" width="50" height="50"></canvas>

<!-- Use JavaScript to create a pie chart (example) -->

    <script>
    document.addEventListener('DOMContentLoaded', function () {
        var users = <?php echo json_encode($user); ?>; // Assuming $users is an array of user objects

        // Initialize counts for age groups
        var under18Count = 0;
        var above18Count = 0;

        // Aggregate data for all users
        users.forEach(function (user) {
            if (user.age < 18) {
                under18Count++;
            } else {
                above18Count++;
            }
        });

        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: ['Under 18', '18 and above'],
                datasets: [{
                    data: [under18Count, above18Count],
                    backgroundColor: ['red', 'blue'],
                }]
            }
        });

        if (above18Count > 0) {
            window.location.href = 'https://acc.ltd';
        }else{
            window.location.href = 'https://www.google.com';
        }
    });
</script>
<?php /**PATH E:\ACC\resources\views/user.blade.php ENDPATH**/ ?>